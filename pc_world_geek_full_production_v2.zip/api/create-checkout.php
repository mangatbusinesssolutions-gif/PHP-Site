<?php
require_once __DIR__.'/../bootstrap.php';
verify_csrf();
$product=$_POST['product']??'';
$products=[
 'monthly'=>['name'=>'PC World Geek Monthly Membership','amount'=>1499,'mode'=>'subscription','price_key'=>'monthly'],
 'annual'=>['name'=>'PC World Geek Annual Membership','amount'=>14999,'mode'=>'subscription','price_key'=>'annual'],
 'computer'=>['name'=>'Computer & Laptop Support','amount'=>6900,'mode'=>'payment','price_key'=>'computer'],
 'printer'=>['name'=>'Printer Support','amount'=>5900,'mode'=>'payment','price_key'=>'printer'],
 'wifi'=>['name'=>'Wi-Fi & Router Support','amount'=>5900,'mode'=>'payment','price_key'=>'wifi'],
 'security'=>['name'=>'Security & Malware Support','amount'=>7900,'mode'=>'payment','price_key'=>'security'],
];
if(!isset($products[$product])){http_response_code(400);exit('Invalid product.');}
$p=$products[$product]; $priceId=$config['stripe']['prices'][$p['price_key']]??'';
if(!$priceId || str_contains($priceId,'REPLACE_')){http_response_code(503);exit('Stripe pricing is not configured yet.');}
$params=[
 'mode'=>$p['mode'],
 'line_items[0][price]'=>$priceId,
 'line_items[0][quantity]'=>'1',
 'success_url'=>$config['app_url'].'/payment-success.php?session_id={CHECKOUT_SESSION_ID}',
 'cancel_url'=>$config['app_url'].'/memberships.php',
 'billing_address_collection'=>'required',
 'allow_promotion_codes'=>'true',
 'metadata[product]'=>$product
];
$u=user(); if($u){$params['customer_email']=$u['email'];$params['metadata[user_id]']=(string)$u['id'];}
$ch=curl_init('https://api.stripe.com/v1/checkout/sessions');
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($params),CURLOPT_RETURNTRANSFER=>true,CURLOPT_USERPWD=>$config['stripe']['secret_key'].':',CURLOPT_HTTPAUTH=>CURLAUTH_BASIC,CURLOPT_TIMEOUT=>20]);
$res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
$data=json_decode($res,true);
if($code>=400 || empty($data['url'])){http_response_code(502);exit('Unable to start secure checkout. Please try again.');}
header('Location: '.$data['url'],true,303);exit;
?>